import QtQuick
import QtQuick3D

Node {
    id: node
    scale: Qt.vector3d(508.16698785821507,508.16698785821507,508.16698785821507)
    position: Qt.vector3d(-0.0,-136.44283097519448,-0.5335720053540646)

    // Resources
    PrincipledMaterial {
        id: bb_Plate_material
        objectName: "BB_Plate"
        baseColor: "#ffad996f"
        metalness: 0.699999988079071
        roughness: 0.5
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Rubber_material
        objectName: "BB_Rubber"
        baseColor: "#ff212122"
        roughness: 0.800000011920929
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Screen_material
        objectName: "BB_Screen"
        baseColor: "#ff121216"
        roughness: 0.05000000074505806
        emissiveFactor: Qt.vector3d(0.008, 0.018, 0.036)
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 1
    }
    PrincipledMaterial {
        id: bb_Frame_material
        objectName: "BB_Frame"
        baseColor: "#ff242528"
        roughness: 0.30000001192092896
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.30000001192092896
    }
    PrincipledMaterial {
        id: bb_Led_material
        objectName: "BB_Led"
        baseColor: "#ff59f3b3"
        roughness: 0.30000001192092896
        emissiveFactor: Qt.vector3d(0.152941, 1, 0.494118)
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_ToolFace_material
        objectName: "BB_ToolFace"
        baseColor: "#ffc3c5c8"
        metalness: 0.20000000298023224
        roughness: 0.30000001192092896
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.4000000059604645
    }
    PrincipledMaterial {
        id: bb_Toolhead_material
        objectName: "BB_Toolhead"
        baseColor: "#ff505255"
        roughness: 0.3499999940395355
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.4000000059604645
    }
    PrincipledMaterial {
        id: bb_Nozzle_material
        objectName: "BB_Nozzle"
        baseColor: "#ffe7c389"
        metalness: 1
        roughness: 0.25
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Metal_material
        objectName: "BB_Metal"
        baseColor: "#ffced0d4"
        metalness: 1
        roughness: 0.2199999988079071
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Filament_material
        objectName: "BB_Filament"
        baseColor: "#ffefefef"
        roughness: 0.3499999940395355
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Reel_material
        objectName: "BB_Reel"
        baseColor: "#ff2c2c2f"
        roughness: 0.44999998807907104
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Shell_material
        objectName: "BB_Shell"
        baseColor: "#ff353639"
        roughness: 0.3400000035762787
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.3499999940395355
    }
    PrincipledMaterial {
        id: bb_Part_material
        objectName: "BB_Part"
        baseColor: "#ffefefef"
        roughness: 0.41999998688697815
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_BedBase_material
        objectName: "BB_BedBase"
        baseColor: "#ff454548"
        metalness: 0.4000000059604645
        roughness: 0.5
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_ShellLight_material
        objectName: "BB_ShellLight"
        baseColor: "#ffced0d3"
        roughness: 0.3799999952316284
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.20000000298023224
    }

    // Nodes:
    Node {
        id: root
        objectName: "ROOT"
        Node {
            id: ams
            objectName: "AMS"
            position: Qt.vector3d(0, 0.445, 0)
            Model {
                id: hub_0
                objectName: "Hub_0"
                position: Qt.vector3d(-0.12375, 0.057, 0)
                rotation: Qt.quaternion(0.627211, 0.627211, -0.326506, 0.326506)
                scale: Qt.vector3d(1, 1, 1)
                source: "meshes/hub_0_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: hub_1
                objectName: "Hub_1"
                position: Qt.vector3d(-0.04125, 0.057, 0)
                rotation: Qt.quaternion(0.627211, 0.627211, -0.326506, 0.326506)
                scale: Qt.vector3d(1, 1, 1)
                source: "meshes/hub_1_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: hub_2
                objectName: "Hub_2"
                position: Qt.vector3d(0.04125, 0.057, 0)
                rotation: Qt.quaternion(0.627211, 0.627211, -0.326506, 0.326506)
                scale: Qt.vector3d(1, 1, 1)
                source: "meshes/hub_2_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: hub_3
                objectName: "Hub_3"
                position: Qt.vector3d(0.12375, 0.057, 0)
                rotation: Qt.quaternion(0.627211, 0.627211, -0.326506, 0.326506)
                scale: Qt.vector3d(1, 1, 1)
                source: "meshes/hub_3_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: liteArm_0
                objectName: "LiteArm_0"
                position: Qt.vector3d(-0.12375, 0.02, -0.02)
                source: "meshes/liteArm_0_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: liteArm_1
                objectName: "LiteArm_1"
                position: Qt.vector3d(-0.04125, 0.02, -0.02)
                source: "meshes/liteArm_1_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: liteArm_2
                objectName: "LiteArm_2"
                position: Qt.vector3d(0.04125, 0.02, -0.02)
                source: "meshes/liteArm_2_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: liteArm_3
                objectName: "LiteArm_3"
                position: Qt.vector3d(0.12375, 0.02, -0.02)
                source: "meshes/liteArm_3_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: liteRail
                objectName: "LiteRail"
                position: Qt.vector3d(0, 0.007, -0.02)
                source: "meshes/liteRail_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Node {
                id: spool_0
                objectName: "Spool_0"
                position: Qt.vector3d(-0.12375, 0.057, 0)
                rotation: Qt.quaternion(0.887011, 0, -0.461749, 0)
                scale: Qt.vector3d(1, 1, 1)
                Model {
                    id: core_0
                    objectName: "Core_0"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_0_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_0
                    objectName: "Filament_0"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_0_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_0_B
                    objectName: "Flange_0_B"
                    position: Qt.vector3d(0, 0, -0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_0_B_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_0_F
                    objectName: "Flange_0_F"
                    position: Qt.vector3d(0, 0, 0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_0_F_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_1
                objectName: "Spool_1"
                position: Qt.vector3d(-0.04125, 0.057, 0)
                rotation: Qt.quaternion(0.887011, 0, -0.461749, 0)
                scale: Qt.vector3d(1, 1, 1)
                Model {
                    id: core_1
                    objectName: "Core_1"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_1_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_1
                    objectName: "Filament_1"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_1_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_1_B
                    objectName: "Flange_1_B"
                    position: Qt.vector3d(0, 0, -0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_1_B_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_1_F
                    objectName: "Flange_1_F"
                    position: Qt.vector3d(0, 0, 0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_1_F_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_2
                objectName: "Spool_2"
                position: Qt.vector3d(0.04125, 0.057, 0)
                rotation: Qt.quaternion(0.887011, 0, -0.461749, 0)
                scale: Qt.vector3d(1, 1, 1)
                Model {
                    id: core_2
                    objectName: "Core_2"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_2_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_2
                    objectName: "Filament_2"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_2_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_2_B
                    objectName: "Flange_2_B"
                    position: Qt.vector3d(0, 0, -0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_2_B_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_2_F
                    objectName: "Flange_2_F"
                    position: Qt.vector3d(0, 0, 0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_2_F_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_3
                objectName: "Spool_3"
                position: Qt.vector3d(0.12375, 0.057, 0)
                rotation: Qt.quaternion(0.887011, 0, -0.461749, 0)
                scale: Qt.vector3d(1, 1, 1)
                Model {
                    id: core_3
                    objectName: "Core_3"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_3_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_3
                    objectName: "Filament_3"
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_3_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_3_B
                    objectName: "Flange_3_B"
                    position: Qt.vector3d(0, 0, -0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_3_B_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_3_F
                    objectName: "Flange_3_F"
                    position: Qt.vector3d(0, 0, 0.017)
                    rotation: Qt.quaternion(0.707107, 0.707107, 0, 0)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_3_F_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
        }
        Model {
            id: base
            objectName: "Base"
            position: Qt.vector3d(0, 0.03, 0)
            source: "meshes/base_mesh.mesh"
            materials: [
                bb_ShellLight_material
            ]
        }
        Model {
            id: baseTrim
            objectName: "BaseTrim"
            position: Qt.vector3d(0, 0.054, 0)
            source: "meshes/baseTrim_mesh.mesh"
            materials: [
                bb_Shell_material
            ]
        }
        Node {
            id: bed
            objectName: "Bed"
            position: Qt.vector3d(0, 0.105, 0)
            Model {
                id: bedFrame
                objectName: "BedFrame"
                position: Qt.vector3d(0, -0.009, 0)
                source: "meshes/bedFrame_mesh.mesh"
                materials: [
                    bb_BedBase_material
                ]
            }
            Model {
                id: bedHeater
                objectName: "BedHeater"
                position: Qt.vector3d(0, -0.02, 0)
                source: "meshes/bedHeater_mesh.mesh"
                materials: [
                    bb_BedBase_material
                ]
            }
            Model {
                id: part_00
                objectName: "Part_00"
                source: "meshes/part_00_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_01
                objectName: "Part_01"
                source: "meshes/part_01_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_02
                objectName: "Part_02"
                source: "meshes/part_02_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_03
                objectName: "Part_03"
                source: "meshes/part_03_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_04
                objectName: "Part_04"
                source: "meshes/part_04_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_05
                objectName: "Part_05"
                source: "meshes/part_05_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_06
                objectName: "Part_06"
                source: "meshes/part_06_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_07
                objectName: "Part_07"
                source: "meshes/part_07_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_08
                objectName: "Part_08"
                source: "meshes/part_08_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_09
                objectName: "Part_09"
                source: "meshes/part_09_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_10
                objectName: "Part_10"
                source: "meshes/part_10_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_11
                objectName: "Part_11"
                source: "meshes/part_11_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_12
                objectName: "Part_12"
                source: "meshes/part_12_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_13
                objectName: "Part_13"
                source: "meshes/part_13_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_14
                objectName: "Part_14"
                source: "meshes/part_14_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_15
                objectName: "Part_15"
                source: "meshes/part_15_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_16
                objectName: "Part_16"
                source: "meshes/part_16_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_17
                objectName: "Part_17"
                source: "meshes/part_17_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_18
                objectName: "Part_18"
                source: "meshes/part_18_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_19
                objectName: "Part_19"
                source: "meshes/part_19_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_20
                objectName: "Part_20"
                source: "meshes/part_20_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_21
                objectName: "Part_21"
                source: "meshes/part_21_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_22
                objectName: "Part_22"
                source: "meshes/part_22_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_23
                objectName: "Part_23"
                source: "meshes/part_23_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_24
                objectName: "Part_24"
                source: "meshes/part_24_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_25
                objectName: "Part_25"
                source: "meshes/part_25_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_26
                objectName: "Part_26"
                source: "meshes/part_26_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_27
                objectName: "Part_27"
                source: "meshes/part_27_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_28
                objectName: "Part_28"
                source: "meshes/part_28_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_29
                objectName: "Part_29"
                source: "meshes/part_29_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_30
                objectName: "Part_30"
                source: "meshes/part_30_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_31
                objectName: "Part_31"
                source: "meshes/part_31_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: plate
                objectName: "Plate"
                position: Qt.vector3d(0, -0.003, 0)
                source: "meshes/plate_mesh.mesh"
                materials: [
                    bb_Plate_material
                ]
            }
            Model {
                id: plateTab
                objectName: "PlateTab"
                position: Qt.vector3d(0, -0.003, -0.132)
                source: "meshes/plateTab_mesh.mesh"
                materials: [
                    bb_Plate_material
                ]
            }
        }
        Model {
            id: foot
            objectName: "Foot"
            position: Qt.vector3d(-0.1425, -0.003, 0.155)
            source: "meshes/foot_mesh.mesh"
            materials: [
                bb_Rubber_material
            ]
        }
        Model {
            id: foot_001
            objectName: "Foot.001"
            position: Qt.vector3d(-0.1425, -0.003, -0.155)
            source: "meshes/foot_001_mesh.mesh"
            materials: [
                bb_Rubber_material
            ]
        }
        Model {
            id: foot_002
            objectName: "Foot.002"
            position: Qt.vector3d(0.1425, -0.003, 0.155)
            source: "meshes/foot_002_mesh.mesh"
            materials: [
                bb_Rubber_material
            ]
        }
        Model {
            id: foot_003
            objectName: "Foot.003"
            position: Qt.vector3d(0.1425, -0.003, -0.155)
            source: "meshes/foot_003_mesh.mesh"
            materials: [
                bb_Rubber_material
            ]
        }
        Node {
            id: gantry
            objectName: "Gantry"
            position: Qt.vector3d(0, 0.2954, 0)
            Node {
                id: toolhead
                objectName: "Toolhead"
                position: Qt.vector3d(0.03072, -0.012, 0.015)
                Model {
                    id: heatsink0
                    objectName: "Heatsink0"
                    position: Qt.vector3d(0, -0.037, 0)
                    source: "meshes/heatsink0_mesh.mesh"
                    materials: [
                        bb_Metal_material
                    ]
                }
                Model {
                    id: nozzleTip0
                    objectName: "NozzleTip0"
                    position: Qt.vector3d(0, -0.047, 0)
                    source: "meshes/nozzleTip0_mesh.mesh"
                    materials: [
                        bb_Nozzle_material
                    ]
                }
                Model {
                    id: toolBody
                    objectName: "ToolBody"
                    source: "meshes/toolBody_mesh.mesh"
                    materials: [
                        bb_Toolhead_material
                    ]
                }
                Model {
                    id: toolFace
                    objectName: "ToolFace"
                    position: Qt.vector3d(0, 0.00600001, 0.026)
                    source: "meshes/toolFace_mesh.mesh"
                    materials: [
                        bb_ToolFace_material
                    ]
                }
                Model {
                    id: toolLed
                    objectName: "ToolLed"
                    position: Qt.vector3d(0, -0.01736, 0.0285)
                    source: "meshes/toolLed_mesh.mesh"
                    materials: [
                        bb_Led_material
                    ]
                }
                Model {
                    id: toolLever
                    objectName: "ToolLever"
                    position: Qt.vector3d(0.021, 0.012, 0.029)
                    source: "meshes/toolLever_mesh.mesh"
                    materials: [
                        bb_Frame_material
                    ]
                }
            }
            Model {
                id: xbeam
                objectName: "XBeam"
                position: Qt.vector3d(0, 0, -0.02)
                source: "meshes/xbeam_mesh.mesh"
                materials: [
                    bb_Shell_material
                ]
            }
            Model {
                id: xrod
                objectName: "XRod"
                position: Qt.vector3d(0, -0.012, -0.004)
                rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                scale: Qt.vector3d(1, 1, 1)
                source: "meshes/xrod_mesh.mesh"
                materials: [
                    bb_Metal_material
                ]
            }
        }
        Model {
            id: screen
            objectName: "Screen"
            position: Qt.vector3d(0.1225, 0.0288, 0.2056)
            source: "meshes/screen_mesh.mesh"
            materials: [
                bb_Screen_material
            ]
        }
        Model {
            id: topBar
            objectName: "TopBar"
            position: Qt.vector3d(0, 0.4275, -0.05)
            source: "meshes/topBar_mesh.mesh"
            materials: [
                bb_ShellLight_material
            ]
        }
        Model {
            id: tower
            objectName: "Tower"
            position: Qt.vector3d(-0.17, 0.2425, -0.05)
            source: "meshes/tower_mesh.mesh"
            materials: [
                bb_ShellLight_material
            ]
        }
        Model {
            id: tower_001
            objectName: "Tower.001"
            position: Qt.vector3d(0.17, 0.2425, -0.05)
            source: "meshes/tower_001_mesh.mesh"
            materials: [
                bb_ShellLight_material
            ]
        }
        Model {
            id: yrailCover
            objectName: "YRailCover"
            position: Qt.vector3d(0, 0.064, 0)
            source: "meshes/yrailCover_mesh.mesh"
            materials: [
                bb_Shell_material
            ]
        }
    }

    // Animations:
}
