import QtQuick
import QtQuick3D

Node {
    id: node
    scale: Qt.vector3d(408.1632671147956,408.1632671147956,408.1632671147956)
    position: Qt.vector3d(-0.0,-140.0,-0.0)

    // Resources
    PrincipledMaterial {
        id: bb_Lamp_material
        objectName: "BB_Lamp"
        baseColor: "#fff9f7f1"
        roughness: 0.30000001192092896
        emissiveFactor: Qt.vector3d(1, 0.95, 0.86)
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Plate_material
        objectName: "BB_Plate"
        baseColor: "#ffad996f"
        metalness: 0.699999988079071
        roughness: 0.5
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Carbon_material
        objectName: "BB_Carbon"
        baseColor: "#ff272729"
        roughness: 0.25
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.6000000238418579
    }
    PrincipledMaterial {
        id: bb_Led_material
        objectName: "BB_Led"
        baseColor: "#ff59f3b3"
        roughness: 0.30000001192092896
        emissiveFactor: Qt.vector3d(0.152941, 1, 0.494118)
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_ToolFace_material
        objectName: "BB_ToolFace"
        baseColor: "#ffc3c5c8"
        metalness: 0.20000000298023224
        roughness: 0.30000001192092896
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.4000000059604645
    }
    PrincipledMaterial {
        id: bb_Toolhead_material
        objectName: "BB_Toolhead"
        baseColor: "#ff505255"
        roughness: 0.3499999940395355
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.4000000059604645
    }
    PrincipledMaterial {
        id: bb_Nozzle_material
        objectName: "BB_Nozzle"
        baseColor: "#ffe7c389"
        metalness: 1
        roughness: 0.25
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Metal_material
        objectName: "BB_Metal"
        baseColor: "#ffced0d4"
        metalness: 1
        roughness: 0.2199999988079071
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Filament_material
        objectName: "BB_Filament"
        baseColor: "#ffefefef"
        roughness: 0.3499999940395355
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Reel_material
        objectName: "BB_Reel"
        baseColor: "#ff2c2c2f"
        roughness: 0.44999998807907104
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_AMS_material
        objectName: "BB_AMS"
        baseColor: "#ff3f4043"
        roughness: 0.4000000059604645
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.20000000298023224
    }
    PrincipledMaterial {
        id: bb_Smoke_material
        objectName: "BB_Smoke"
        baseColor: "#8c6f6f73"
        roughness: 0.029999999329447746
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Blend
        transmissionFactor: 1
    }
    PrincipledMaterial {
        id: bb_Frame_material
        objectName: "BB_Frame"
        baseColor: "#ff242528"
        roughness: 0.30000001192092896
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.30000001192092896
    }
    PrincipledMaterial {
        id: bb_Part_material
        objectName: "BB_Part"
        baseColor: "#ffefefef"
        roughness: 0.41999998688697815
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_BedBase_material
        objectName: "BB_BedBase"
        baseColor: "#ff454548"
        metalness: 0.4000000059604645
        roughness: 0.5
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }
    PrincipledMaterial {
        id: bb_Shell_material
        objectName: "BB_Shell"
        baseColor: "#ff353639"
        roughness: 0.3400000035762787
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
        clearcoatAmount: 0.3499999940395355
    }
    PrincipledMaterial {
        id: bb_Inner_material
        objectName: "BB_Inner"
        baseColor: "#ff353638"
        roughness: 0.75
        cullMode: PrincipledMaterial.NoCulling
        alphaMode: PrincipledMaterial.Opaque
    }

    // Nodes:
    Node {
        id: root
        objectName: "ROOT"
        Node {
            id: ams
            objectName: "AMS"
            position: Qt.vector3d(0, 0.458, 0)
            Model {
                id: amsband
                objectName: "AMSBand"
                position: Qt.vector3d(0, 0.12924, 0)
                source: "meshes/amsband_mesh.mesh"
                materials: [
                    bb_Frame_material
                ]
            }
            Model {
                id: amslatch
                objectName: "AMSLatch"
                position: Qt.vector3d(0, 0.11824, 0.1445)
                source: "meshes/amslatch_mesh.mesh"
                materials: [
                    bb_Frame_material
                ]
            }
            Model {
                id: amslid
                objectName: "AMSLid"
                position: Qt.vector3d(0, 0.18012, 0)
                source: "meshes/amslid_mesh.mesh"
                materials: [
                    bb_Smoke_material
                ]
            }
            Model {
                id: amstub
                objectName: "AMSTub"
                position: Qt.vector3d(0, 0.06612, 0)
                source: "meshes/amstub_mesh.mesh"
                materials: [
                    bb_AMS_material
                ]
            }
            Node {
                id: spool_0
                objectName: "Spool_0"
                position: Qt.vector3d(-0.12, 0.112, 0)
                Model {
                    id: core_0
                    objectName: "Core_0"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_0_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_0
                    objectName: "Filament_0"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_0_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_0_L
                    objectName: "Flange_0_L"
                    position: Qt.vector3d(-0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_0_L_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_0_R
                    objectName: "Flange_0_R"
                    position: Qt.vector3d(0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_0_R_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_1
                objectName: "Spool_1"
                position: Qt.vector3d(-0.04, 0.112, 0)
                Model {
                    id: core_1
                    objectName: "Core_1"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_1_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_1
                    objectName: "Filament_1"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_1_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_1_L
                    objectName: "Flange_1_L"
                    position: Qt.vector3d(-0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_1_L_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_1_R
                    objectName: "Flange_1_R"
                    position: Qt.vector3d(0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_1_R_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_2
                objectName: "Spool_2"
                position: Qt.vector3d(0.04, 0.112, 0)
                Model {
                    id: core_2
                    objectName: "Core_2"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_2_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_2
                    objectName: "Filament_2"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_2_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_2_L
                    objectName: "Flange_2_L"
                    position: Qt.vector3d(-0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_2_L_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_2_R
                    objectName: "Flange_2_R"
                    position: Qt.vector3d(0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_2_R_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
            Node {
                id: spool_3
                objectName: "Spool_3"
                position: Qt.vector3d(0.12, 0.112, 0)
                Model {
                    id: core_3
                    objectName: "Core_3"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/core_3_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: filament_3
                    objectName: "Filament_3"
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/filament_3_mesh.mesh"
                    materials: [
                        bb_Filament_material
                    ]
                }
                Model {
                    id: flange_3_L
                    objectName: "Flange_3_L"
                    position: Qt.vector3d(-0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_3_L_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
                Model {
                    id: flange_3_R
                    objectName: "Flange_3_R"
                    position: Qt.vector3d(0.0315, 0, 0)
                    rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
                    scale: Qt.vector3d(1, 1, 1)
                    source: "meshes/flange_3_R_mesh.mesh"
                    materials: [
                        bb_Reel_material
                    ]
                }
            }
        }
        Model {
            id: backPanel
            objectName: "BackPanel"
            position: Qt.vector3d(0, 0.255, -0.1845)
            source: "meshes/backPanel_mesh.mesh"
            materials: [
                bb_Inner_material
            ]
        }
        Model {
            id: base
            objectName: "Base"
            position: Qt.vector3d(0, 0.0425, 0)
            source: "meshes/base_mesh.mesh"
            materials: [
                bb_Shell_material
            ]
        }
        Node {
            id: bedCarriage
            objectName: "BedCarriage"
            position: Qt.vector3d(0, 0.17516, -0.004)
            Model {
                id: bedFrame
                objectName: "BedFrame"
                position: Qt.vector3d(0, -0.009, 0)
                source: "meshes/bedFrame_mesh.mesh"
                materials: [
                    bb_BedBase_material
                ]
            }
            Model {
                id: part_00
                objectName: "Part_00"
                source: "meshes/part_00_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_01
                objectName: "Part_01"
                source: "meshes/part_01_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_02
                objectName: "Part_02"
                source: "meshes/part_02_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_03
                objectName: "Part_03"
                source: "meshes/part_03_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_04
                objectName: "Part_04"
                source: "meshes/part_04_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_05
                objectName: "Part_05"
                source: "meshes/part_05_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_06
                objectName: "Part_06"
                source: "meshes/part_06_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_07
                objectName: "Part_07"
                source: "meshes/part_07_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_08
                objectName: "Part_08"
                source: "meshes/part_08_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_09
                objectName: "Part_09"
                source: "meshes/part_09_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_10
                objectName: "Part_10"
                source: "meshes/part_10_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_11
                objectName: "Part_11"
                source: "meshes/part_11_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_12
                objectName: "Part_12"
                source: "meshes/part_12_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_13
                objectName: "Part_13"
                source: "meshes/part_13_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_14
                objectName: "Part_14"
                source: "meshes/part_14_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_15
                objectName: "Part_15"
                source: "meshes/part_15_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_16
                objectName: "Part_16"
                source: "meshes/part_16_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_17
                objectName: "Part_17"
                source: "meshes/part_17_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_18
                objectName: "Part_18"
                source: "meshes/part_18_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_19
                objectName: "Part_19"
                source: "meshes/part_19_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_20
                objectName: "Part_20"
                source: "meshes/part_20_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_21
                objectName: "Part_21"
                source: "meshes/part_21_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_22
                objectName: "Part_22"
                source: "meshes/part_22_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_23
                objectName: "Part_23"
                source: "meshes/part_23_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_24
                objectName: "Part_24"
                source: "meshes/part_24_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_25
                objectName: "Part_25"
                source: "meshes/part_25_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_26
                objectName: "Part_26"
                source: "meshes/part_26_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_27
                objectName: "Part_27"
                source: "meshes/part_27_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_28
                objectName: "Part_28"
                source: "meshes/part_28_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_29
                objectName: "Part_29"
                source: "meshes/part_29_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_30
                objectName: "Part_30"
                source: "meshes/part_30_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: part_31
                objectName: "Part_31"
                source: "meshes/part_31_mesh.mesh"
                materials: [
                    bb_Part_material
                ]
            }
            Model {
                id: plate
                objectName: "Plate"
                position: Qt.vector3d(0, -0.00300001, 0)
                source: "meshes/plate_mesh.mesh"
                materials: [
                    bb_Plate_material
                ]
            }
            Model {
                id: plateTab
                objectName: "PlateTab"
                position: Qt.vector3d(0, -0.00300001, -0.13054)
                source: "meshes/plateTab_mesh.mesh"
                materials: [
                    bb_Plate_material
                ]
            }
        }
        Model {
            id: chute
            objectName: "Chute"
            position: Qt.vector3d(-0.141, 0.115, -0.1425)
            source: "meshes/chute_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Model {
            id: lamp
            objectName: "Lamp"
            position: Qt.vector3d(-0.06156, 0.401, 0.1425)
            source: "meshes/lamp_mesh.mesh"
            materials: [
                bb_Lamp_material
            ]
        }
        Model {
            id: post
            objectName: "Post"
            position: Qt.vector3d(-0.178, 0.229, 0.1795)
            source: "meshes/post_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Model {
            id: post_001
            objectName: "Post.001"
            position: Qt.vector3d(-0.178, 0.229, -0.1795)
            source: "meshes/post_001_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Model {
            id: post_002
            objectName: "Post.002"
            position: Qt.vector3d(0.178, 0.229, 0.1795)
            source: "meshes/post_002_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Model {
            id: post_003
            objectName: "Post.003"
            position: Qt.vector3d(0.178, 0.229, -0.1795)
            source: "meshes/post_003_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Node {
            id: toolhead
            objectName: "Toolhead"
            position: Qt.vector3d(0.02736, 0.352, 0.02)
            Model {
                id: heatsink0
                objectName: "Heatsink0"
                position: Qt.vector3d(0, -0.042, 0)
                source: "meshes/heatsink0_mesh.mesh"
                materials: [
                    bb_Metal_material
                ]
            }
            Model {
                id: nozzleTip0
                objectName: "NozzleTip0"
                position: Qt.vector3d(0, -0.052, 0)
                source: "meshes/nozzleTip0_mesh.mesh"
                materials: [
                    bb_Nozzle_material
                ]
            }
            Model {
                id: toolBody
                objectName: "ToolBody"
                source: "meshes/toolBody_mesh.mesh"
                materials: [
                    bb_Toolhead_material
                ]
            }
            Model {
                id: toolFace
                objectName: "ToolFace"
                position: Qt.vector3d(0, 0.00600001, 0.031)
                source: "meshes/toolFace_mesh.mesh"
                materials: [
                    bb_ToolFace_material
                ]
            }
            Model {
                id: toolLed
                objectName: "ToolLed"
                position: Qt.vector3d(0, -0.02016, 0.0335)
                source: "meshes/toolLed_mesh.mesh"
                materials: [
                    bb_Led_material
                ]
            }
            Model {
                id: toolLever
                objectName: "ToolLever"
                position: Qt.vector3d(0.027, 0.012, 0.034)
                source: "meshes/toolLever_mesh.mesh"
                materials: [
                    bb_Frame_material
                ]
            }
        }
        Model {
            id: topRing
            objectName: "TopRing"
            position: Qt.vector3d(0, 0.4415, 0)
            source: "meshes/topRing_mesh.mesh"
            materials: [
                bb_Frame_material
            ]
        }
        Model {
            id: xrod
            objectName: "XRod"
            position: Qt.vector3d(0, 0.358, 0.03)
            rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
            scale: Qt.vector3d(1, 1, 1)
            source: "meshes/xrod_mesh.mesh"
            materials: [
                bb_Carbon_material
            ]
        }
        Model {
            id: xrod2
            objectName: "XRod2"
            position: Qt.vector3d(0, 0.358, 0)
            rotation: Qt.quaternion(0.707107, 0, 0, -0.707107)
            scale: Qt.vector3d(1, 1, 1)
            source: "meshes/xrod2_mesh.mesh"
            materials: [
                bb_Carbon_material
            ]
        }
        Model {
            id: yrail
            objectName: "YRail"
            position: Qt.vector3d(-0.159, 0.358, 0)
            source: "meshes/yrail_mesh.mesh"
            materials: [
                bb_Metal_material
            ]
        }
        Model {
            id: yrail_001
            objectName: "YRail.001"
            position: Qt.vector3d(0.159, 0.358, 0)
            source: "meshes/yrail_001_mesh.mesh"
            materials: [
                bb_Metal_material
            ]
        }
        Model {
            id: zscrew
            objectName: "ZScrew"
            position: Qt.vector3d(-0.13854, 0.244, -0.10654)
            source: "meshes/zscrew_mesh.mesh"
            materials: [
                bb_Metal_material
            ]
        }
        Model {
            id: zscrew_001
            objectName: "ZScrew.001"
            position: Qt.vector3d(0.13854, 0.244, -0.10654)
            source: "meshes/zscrew_001_mesh.mesh"
            materials: [
                bb_Metal_material
            ]
        }
        Model {
            id: zscrew_002
            objectName: "ZScrew.002"
            position: Qt.vector3d(0, 0.244, -0.15654)
            source: "meshes/zscrew_002_mesh.mesh"
            materials: [
                bb_Metal_material
            ]
        }
    }

    // Animations:
}
